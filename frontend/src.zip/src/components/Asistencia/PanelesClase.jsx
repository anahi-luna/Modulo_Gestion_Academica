import { useEffect, useState } from "react";
import { MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import { getComisiones } from "../../mocks/comisionesMock";
import ComisionCard from "./ComisionCard";

export default function PanelesClase({
    comisionSeleccionada,
    setComisionSeleccionada
}) {
    const [comisiones, setComisiones] = useState([]);

    // Carga las comisiones al montar el componente
    useEffect(() => {
        async function cargarComisiones() {
            try {
                const resultado = await getComisiones();
                setComisiones(resultado.data);

                if (resultado.data.length > 0) {
                    setComisionSeleccionada(resultado.data[0]);
                }
            } catch (error) {
                console.error(error);
            }
        }
        cargarComisiones();
    }, []);

    return (
        // Antes: "col-span-3" fijo (rompía en mobile porque el grid
        // padre tiene 12 columnas incluso en pantallas chicas).
        // Ahora: en mobile ocupa el ancho completo, y recién en lg
        // vuelve a ocupar 3 de las 12 columnas.
        <div className="lg:col-span-3 bg-white rounded-xl shadow border p-4 sm:p-5">

            <div className="flex justify-between items-center mb-4 sm:mb-5">
                <h2 className="text-lg sm:text-xl font-semibold">
                    Comisiones
                </h2>
            </div>

            <div className="relative mb-4 sm:mb-5">
                <MagnifyingGlassIcon
                    className="absolute left-3 top-3 h-5 w-5 text-gray-400"
                />
                <input
                    placeholder="Buscar clase..."
                    className="w-full rounded-lg border border-gray-300 py-3 pl-10 pr-3 focus:border-red-600 focus:ring-2 focus:ring-red-200 outline-none"
                />
            </div>

            {/* max-h más chico en mobile (max-h-72) para no ocupar media pantalla;
                en desktop (lg) vuelve a los 600px originales. */}
            <div className="space-y-3 overflow-y-auto max-h-72 lg:max-h-[600px] pr-1">
                {comisiones.map((comision) => (
                    <ComisionCard
                        key={comision.id}
                        comision={comision}
                        seleccionada={comision.id === comisionSeleccionada?.id}
                        onClick={() => setComisionSeleccionada(comision)}
                    />
                ))}
            </div>

        </div>
    )
}